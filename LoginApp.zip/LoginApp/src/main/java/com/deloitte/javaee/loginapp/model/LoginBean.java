package com.deloitte.javaee.loginapp.model;

import java.io.Serializable;
import java.sql.SQLException;

import com.deloitte.javaee.loginapp.dao.LoginDAO;

public class LoginBean implements Serializable{
	
	private int userId;
	private String password;
	
	public LoginBean() {
		// TODO Auto-generated constructor stub
	}

	public LoginBean(int userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return userId+" "+password;
	}
	
	public boolean validateUser(LoginBean loginBean) throws ClassNotFoundException, SQLException {
		//logic
		LoginDAO loginDAO=new LoginDAO();
		return loginDAO.getUser(loginBean);
	}
	

}
