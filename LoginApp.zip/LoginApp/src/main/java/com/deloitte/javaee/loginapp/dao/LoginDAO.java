package com.deloitte.javaee.loginapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.deloitte.javaee.loginapp.model.LoginBean;

public class LoginDAO {

	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "root");

	}
	
	public boolean getUser(LoginBean loginBean) throws ClassNotFoundException, SQLException {
		Connection connection = getConnection();
		Statement stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery("select * from login where user_id="+loginBean.getUserId()+" and password='"+loginBean.getPassword()+"'");
		if(rs.next()) {
			return true;
		}
		return false;
	}
	
	

}
